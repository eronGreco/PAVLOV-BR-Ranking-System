let currentSearchResult = [];
const MIN_SEARCH_LENGTH = 4;

async function fetchPlayerData(playerName) {
    try {
        const response = await fetch(`http://api.pavlovbr.com.br/api/PavlovShackStats/PlayerStats?playerName=${playerName}`);
        if (response.ok) {
            const data = await response.json();
            return Array.isArray(data) ? data[0] : data;
        } else {
            throw new Error('Falha ao carregar dados do jogador');
        }
    } catch (error) {
        console.error("Erro:", error);
    }
}

function calculateScore(player) {
    return ((player.kills || 0) * 2) - ((player.death || 0) * 2) + ((player.headShot || 0) * 1) +
           ((player.assist || 0) * 1) + ((player.bombDefused || 0) * 2) +
           ((player.bombPlanted || 0) * 1) - ((player.teamKill || 0) * 5);
}

async function searchPlayer(input) {
    if (input.length >= MIN_SEARCH_LENGTH) {
        try {
            const response = await fetch(`http://api.pavlovbr.com.br/api/PavlovShackStats/PlayerStats?playerName=${input}`);
            if (response.ok) {
                currentSearchResult = await response.json();
                // Implemente aqui a lógica para mostrar sugestões de nomes de jogadores
            } else {
                console.error('Erro ao buscar jogadores');
            }
        } catch (error) {
            console.error("Erro:", error);
        }
    }
}

function confirmPlayer() {
    const playerName = document.getElementById('searchInput').value.trim().toLowerCase();
    const player = currentSearchResult.find(p => p.playerName.toLowerCase() === playerName);

    if (player) {
        displayPlayerData(player);
    } else {
        alert('Jogador não encontrado. Por favor, verifique o nome e tente novamente.');
    }
}

function displayPlayerData(playerData) {
    if (playerData) {
        document.getElementById('playerName').textContent = playerData.playerName || 'Jogador Desconhecido';
        document.getElementById('playerScore').textContent = 'Pontuação Total: ' + (calculateScore(playerData) || 0);
        document.getElementById('kills').textContent = 'Matou: ' + (playerData.kills || 0);
        document.getElementById('deaths').textContent = 'Morreu: ' + (playerData.death || 0);
        document.getElementById('assists').textContent = 'Assistências: ' + (playerData.assist || 0);
        document.getElementById('headshots').textContent = 'Tiros na Cabeça: ' + (playerData.headShot || 0);
        document.getElementById('bombDefused').textContent = 'Bombas Desarmadas: ' + (playerData.bombDefused || 0);
        document.getElementById('bombPlanted').textContent = 'Bombas Plantadas: ' + (playerData.bombPlanted || 0);
        document.getElementById('teamKill').textContent = 'Aliados Mortos: ' + (playerData.teamKill || 0);
    }
}
