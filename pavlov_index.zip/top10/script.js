document.addEventListener('DOMContentLoaded', function() {
  fetch('http://api.pavlovbr.com.br/api/PavlovShackStats/PlayersStats')
    .then(response => response.json())
    .then(data => {
      const sortedPlayers = data.sort((a, b) => calculateScore(b) - calculateScore(a)).slice(0, 100);
      const leaderboardList = document.querySelector('.leaderboard-list');

      sortedPlayers.forEach((player, index) => {
        const playerCard = document.createElement('div');
        playerCard.className = 'player-card';
        
        if (index === 0) {
          playerCard.classList.add('top1');
        } else if (index === 1) {
          playerCard.classList.add('top2');
        } else if (index === 2) {
          playerCard.classList.add('top3');
        }
        
        const playerName = window.innerWidth <= 600 ? truncatePlayerName(player.playerName) : player.playerName;
        playerCard.innerHTML = `
          <div class="player-header">
            <div class="player-profile">
              <img src="images/semimagem.png" alt="${playerName}">
              <div>
                <div class="player-name">${playerName}</div>
              </div>
            </div>
            <div class="player-score">
              <span class="player-rank">#${index + 1}</span><br> ${calculateScore(player)}
            </div>
          </div>
          <div class="player-info">
            <div>Matou: ${player.kills}</div>
            <div>Morreu: ${player.death}</div>
            <div>Assistências: ${player.assist}</div>
          </div>
        `;
        leaderboardList.appendChild(playerCard);

        // Adiciona uma divisão após o top 3 e o top 10
        if (index === 2 || index === 9) {
          const divider = document.createElement('div');
          divider.className = 'divider';
          leaderboardList.appendChild(divider);
        }
      });
    })
    .catch(error => console.error('Error:', error));
});

function truncatePlayerName(name) {
  return name.length > 13 ? name.substring(0, 13) + '...' : name;
}

function calculateScore(player) {
  return player.kills * 2 +
         player.death * -2 +
         player.headShot * 1 +
         player.assist * 1 +
         player.bombDefused * 2 +
         player.bombPlanted * 1 +
         player.teamKill * -5;
}
